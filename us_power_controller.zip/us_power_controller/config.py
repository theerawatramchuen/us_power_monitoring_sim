"""Configuration handling for the US Power Monitoring Controller.

config.json holds the instrument setup (probe scaling, ranges, timebase,
trigger) and server/logging options.  The power-limit tables and other
operator settings live in data/panel_settings.json and are managed by the
web UI.
"""
from __future__ import annotations

import copy
import json
import math
import os
import tempfile
from pathlib import Path

# Input ranges (+/- volts) offered by the PicoScope 2204A, in driver-enum order.
RANGES_V = [0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0, 20.0]

DEFAULT_CONFIG = {
    "server": {
        "host": "127.0.0.1",          # use "0.0.0.0" to allow other PCs on the LAN to view the screen
        "port": 8080,
        "open_browser": True,
        "autostart_monitoring": True,
    },
    "scope": {
        "driver": "auto",             # "auto" (ps2000 then ps2000a), "ps2000" (2204A/2205A), "ps2000a" (2205 MSO, 2206+), "sim"
        # CH1: Tektronix CT1 current probe.  5 mV/mA = 5 V/A, valid ONLY into a 50 ohm load.
        "ch1": {"range_v": 2.0, "coupling": "AC", "volts_per_amp": 5.0, "invert": False},
        # CH2: AC voltage.  probe_ratio = 10 for a x10 probe, 1 for a x1 probe / direct connection.
        "ch2": {"range_v": 5.0, "coupling": "AC", "probe_ratio": 10.0, "invert": False},
        "capture_window_ms": 100.0,   # time covered by one capture
        "samples": 4000,              # samples per channel (2204A: 8 kS memory shared by 2 channels)
        "pre_trigger_pct": 2.0,       # part of the capture placed before the trigger point
        # Level is in volts AT THE SCOPE INPUT (i.e. after the probe), not at the generator output.
        "trigger": {"source": "CH2", "level_v": 0.5, "direction": "RISING", "auto_ms": 0},
        # Optional test signal: play a DSO csv (TIME,CH1) from the scope's own generator BNC (2204A AWG) while
        # monitoring.  Wire the generator BNC to CH1 and CH2.  Takes effect at start-up.
        "awg": {"enabled": False, "csv": "tek0001.csv", "scale": 1.0},
    },
    "logging": {
        "directory": "logs",
        "captures_directory": "captures",
        "save_captures": "alarms",    # "off" | "alarms" | "all"
        "max_capture_files": 2000,
    },
}


def deep_merge(base: dict, over: dict | None) -> dict:
    out = copy.deepcopy(base)
    for key, val in (over or {}).items():
        if isinstance(val, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], val)
        else:
            out[key] = copy.deepcopy(val)
    return out


def _num(name: str, value, lo: float, hi: float) -> float:
    try:
        x = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be a number") from None
    if not math.isfinite(x):
        raise ValueError(f"{name} must be a finite number")
    if x < lo or x > hi:
        raise ValueError(f"{name} must be between {lo:g} and {hi:g}")
    return x


def _choice(name: str, value, options) -> str:
    s = str(value).upper()
    if s not in options:
        raise ValueError(f"{name} must be one of {', '.join(options)}")
    return s


def snap_range(value: float) -> float:
    """Return the supported input range closest (in log terms) to `value`."""
    x = _num("range_v", value, 0.001, 100.0)
    return min(RANGES_V, key=lambda r: abs(math.log(r) - math.log(x)))


def validate_scope(scope: dict) -> dict:
    """Return a normalised copy of the scope section or raise ValueError."""
    s = deep_merge(DEFAULT_CONFIG["scope"], scope)
    out: dict = {}
    out["driver"] = str(s["driver"]).lower()
    if out["driver"] not in ("auto", "ps2000", "ps2000a", "sim"):
        raise ValueError("driver must be 'auto', 'ps2000', 'ps2000a' or 'sim'")

    c1 = s["ch1"]
    out["ch1"] = {
        "range_v": snap_range(c1["range_v"]),
        "coupling": _choice("ch1.coupling", c1["coupling"], ("AC", "DC")),
        "volts_per_amp": _num("ch1.volts_per_amp", c1["volts_per_amp"], 1e-4, 1e3),
        "invert": bool(c1["invert"]),
    }
    c2 = s["ch2"]
    out["ch2"] = {
        "range_v": snap_range(c2["range_v"]),
        "coupling": _choice("ch2.coupling", c2["coupling"], ("AC", "DC")),
        "probe_ratio": _num("ch2.probe_ratio", c2["probe_ratio"], 0.001, 1e4),
        "invert": bool(c2["invert"]),
    }
    out["capture_window_ms"] = _num("capture_window_ms", s["capture_window_ms"], 0.1, 10000.0)
    out["samples"] = int(_num("samples", s["samples"], 100, 8000))
    out["pre_trigger_pct"] = _num("pre_trigger_pct", s["pre_trigger_pct"], 0.0, 90.0)

    t = s["trigger"]
    out["trigger"] = {
        "source": _choice("trigger.source", t["source"], ("CH1", "CH2", "NONE")),
        "level_v": _num("trigger.level_v", t["level_v"], -20.0, 20.0),
        "direction": _choice("trigger.direction", t["direction"], ("RISING", "FALLING")),
        "auto_ms": int(_num("trigger.auto_ms", t["auto_ms"], 0, 32767)),
    }
    a = s["awg"]
    out["awg"] = {"enabled": bool(a["enabled"]), "csv": str(a["csv"]), "scale": _num("awg.scale", a["scale"], 0.001, 100.0)}
    return out


def validate_config(cfg: dict) -> dict:
    out = deep_merge(DEFAULT_CONFIG, cfg)
    srv = out["server"]
    srv["port"] = int(_num("server.port", srv["port"], 1, 65535))
    srv["host"] = str(srv["host"])
    srv["open_browser"] = bool(srv["open_browser"])
    srv["autostart_monitoring"] = bool(srv["autostart_monitoring"])
    out["scope"] = validate_scope(out["scope"])
    lg = out["logging"]
    lg["directory"] = str(lg["directory"])
    lg["captures_directory"] = str(lg["captures_directory"])
    lg["save_captures"] = str(lg["save_captures"]).lower()
    if lg["save_captures"] not in ("off", "alarms", "all"):
        raise ValueError("logging.save_captures must be 'off', 'alarms' or 'all'")
    lg["max_capture_files"] = int(_num("logging.max_capture_files", lg["max_capture_files"], 10, 1_000_000))
    return out


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def load_config(path: Path) -> dict:
    cfg: dict = {}
    if path.exists():
        try:
            cfg = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise SystemExit(f"Cannot read {path}: {exc}")
    try:
        return validate_config(cfg)
    except ValueError as exc:
        raise SystemExit(f"Invalid setting in {path}: {exc}")


def save_config(path: Path, cfg: dict) -> None:
    atomic_write_text(path, json.dumps(cfg, indent=2) + "\n")
