"""Exercises scope_pico.PicoScope2000A against a fake `picosdk` module (no hardware needed).

What this proves: the call sequence, timebase search, trigger-level conversion, buffer handling and
ADC->volts->amps/volts scaling in our code.  What it cannot prove: that the real ps2000a.dll behaves
like the fake.  A second test cross-checks every driver symbol we call against the real picosdk
wrapper source when PICOSDK_SRC points at a checkout of picosdk-python-wrappers.

Run:  python tests/test_pico_driver_fake.py
"""
import ctypes
import os
import re
import sys
import types
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

PICO_STATUS = {"PICO_OK": 0, "PICO_NOT_FOUND": 3, "PICO_INVALID_TIMEBASE": 14}
RANGE_NAMES = ["PS2000A_10MV", "PS2000A_20MV", "PS2000A_50MV", "PS2000A_100MV", "PS2000A_200MV",
               "PS2000A_500MV", "PS2000A_1V", "PS2000A_2V", "PS2000A_5V", "PS2000A_10V", "PS2000A_20V"]
MAX_ADC = 32512


class FakePs:
    """Mimics the subset of picosdk.ps2000a.ps2000a that scope_pico uses."""
    PS2000A_CHANNEL = {"PS2000A_CHANNEL_A": 0, "PS2000A_CHANNEL_B": 1}
    PS2000A_COUPLING = {"PS2000A_AC": 0, "PS2000A_DC": 1}
    PS2000A_RANGE = {n: i for i, n in enumerate(RANGE_NAMES)}
    PS2000A_THRESHOLD_DIRECTION = {"PS2000A_RISING": 2, "PS2000A_FALLING": 3}
    PS2000A_RATIO_MODE = {"PS2000A_RATIO_MODE_NONE": 0}

    def __init__(self, max_samples=4096):
        self.calls = []
        self.max_samples = max_samples
        self.buffers = {}
        self.stopped = 0

    def ps2000aOpenUnit(self, ref, serial):
        self.calls.append(("OpenUnit",))
        return 0

    def ps2000aGetUnitInfo(self, handle, buf, length, req, info):
        buf.value = b"2204A" if info == 3 else b"AB123/0001"
        return 0

    def ps2000aMaximumValue(self, handle, ref):
        ref._obj.value = MAX_ADC
        return 0

    def ps2000aSetChannel(self, handle, ch, enabled, coupling, rng, offset):
        self.calls.append(("SetChannel", ch, enabled, coupling, rng, offset))
        return 0

    def ps2000aSetSimpleTrigger(self, handle, enable, src, thr, direction, delay, auto_ms):
        self.calls.append(("SetSimpleTrigger", enable, src, thr, direction, delay, auto_ms))
        return 0

    def ps2000aGetTimebase2(self, handle, tb, n, interval_ref, oversample, max_ref, seg):
        if tb < 1:
            return PICO_STATUS["PICO_INVALID_TIMEBASE"]       # fastest timebases unavailable with 2 channels
        interval_ref._obj.value = (tb - 2) / 125e6 * 1e9 if tb >= 3 else float(2 ** tb)
        max_ref._obj.value = self.max_samples
        return 0

    def ps2000aRunBlock(self, handle, pre, post, tb, oversample, t_ind, seg, cb, param):
        self.calls.append(("RunBlock", pre, post, tb))
        return 0

    def ps2000aIsReady(self, handle, ref):
        ref._obj.value = 1
        return 0

    def ps2000aSetDataBuffers(self, handle, ch, ptr, ptr_min, n, seg, mode):
        self.buffers[ch] = (ctypes.cast(ptr, ctypes.c_void_p).value, n)
        return 0

    def ps2000aGetValues(self, handle, start, count_ref, ds, mode, seg, ovf_ref):
        n = count_ref._obj.value
        t = np.arange(n)
        ch_a = (0.5 / 2.0 * MAX_ADC * np.sin(t / 7.0)).astype(np.int16)          # 0.5 V peak on the 2 V range
        ch_b = np.clip(5.2 / 5.0 * MAX_ADC * np.sin(t / 7.0), -MAX_ADC, MAX_ADC).astype(np.int16)  # over-range
        for ch, data in ((0, ch_a), (1, ch_b)):
            addr, _ = self.buffers[ch]
            ctypes.memmove(addr, data.ctypes.data, n * 2)
        ovf_ref._obj.value = 0b10
        return 0

    def ps2000aStop(self, handle):
        self.stopped += 1
        return 0

    def ps2000aCloseUnit(self, handle):
        self.calls.append(("CloseUnit",))
        return 0


def install_fake(max_samples=4096) -> FakePs:
    fake = FakePs(max_samples)
    pkg = types.ModuleType("picosdk")
    mod = types.ModuleType("picosdk.ps2000a")
    mod.ps2000a = fake
    const = types.ModuleType("picosdk.constants")
    const.PICO_STATUS = PICO_STATUS
    const.PICO_STATUS_LOOKUP = {v: k for k, v in PICO_STATUS.items()}
    sys.modules.update({"picosdk": pkg, "picosdk.ps2000a": mod, "picosdk.constants": const})
    sys.modules.pop("scope_pico", None)
    return fake


def scope_cfg(**over):
    from config import validate_scope
    return validate_scope(over)


def test_configure_and_read():
    fake = install_fake()
    from scope_pico import PicoScope2000A
    from common import scale_capture
    s = PicoScope2000A()
    info = s.open()
    assert info == {"model": "PicoScope 2204A", "serial": "AB123/0001"}, info

    cfg = scope_cfg()      # defaults: CH1 2 V / 5 V per A, CH2 5 V x10, 100 ms, 4000 samples, trigger CH2 0.5 V rising
    applied = s.configure(cfg)
    assert applied["samples"] == 4000 and applied["pre_samples"] == 80 and applied["post_samples"] == 3920, applied
    assert abs(applied["dt"] - 25e-6) < 1e-9 and applied["timebase"] == 3127, applied

    trig = [c for c in fake.calls if c[0] == "SetSimpleTrigger"][-1]
    # level 0.5 V on the CH2 5 V range -> 0.1 * 32512 counts, source B, rising (2), auto 0
    assert trig == ("SetSimpleTrigger", 1, 1, 3251, 2, 0, 0), trig
    chans = [c for c in fake.calls if c[0] == "SetChannel"]
    assert chans[0][1:] == (0, 1, 0, RANGE_NAMES.index("PS2000A_2V"), 0.0), chans[0]       # CH1: AC, 2 V
    assert chans[1][1:] == (1, 1, 0, RANGE_NAMES.index("PS2000A_5V"), 0.0), chans[1]       # CH2: AC, 5 V

    s.arm()
    assert [c for c in fake.calls if c[0] == "RunBlock"][-1] == ("RunBlock", 80, 3920, 3127)
    assert s.is_ready()
    raw = s.read()
    assert raw.ch1_v.size == 4000 and raw.ch2_v.size == 4000
    assert abs(raw.t0 + 80 * 25e-6) < 1e-9
    assert abs(float(raw.ch1_v.max()) - 0.5) < 0.01, raw.ch1_v.max()
    assert raw.flags["clip_ch2"] and raw.flags["overflow_ch2"] and not raw.flags["clip_ch1"], raw.flags

    frame = scale_capture(raw, cfg, 1, 0.0)
    assert abs(float(frame.current_a.max()) - 0.1) < 0.003, frame.current_a.max()    # 0.5 V / 5 V per A
    assert abs(float(frame.voltage_v.max()) - 50.0) < 0.5, frame.voltage_v.max()     # 5.0 V x 10 probe
    s.close()
    assert fake.calls[-1] == ("CloseUnit",)


def test_memory_cap_reduces_samples():
    install_fake(max_samples=2500)
    from scope_pico import PicoScope2000A
    s = PicoScope2000A()
    s.open()
    applied = s.configure(scope_cfg(samples=4000))
    assert applied["samples"] == 2500 and applied["samples_requested"] == 4000, applied
    assert s.read().ch1_v.size == 2500


def test_trigger_none_and_falling():
    fake = install_fake()
    from scope_pico import PicoScope2000A
    s = PicoScope2000A()
    s.open()
    s.configure(scope_cfg(trigger={"source": "NONE"}))
    assert [c for c in fake.calls if c[0] == "SetSimpleTrigger"][-1][1] == 0
    s.configure(scope_cfg(trigger={"source": "CH1", "direction": "FALLING", "level_v": -0.2, "auto_ms": 250}))
    trig = [c for c in fake.calls if c[0] == "SetSimpleTrigger"][-1]
    assert trig == ("SetSimpleTrigger", 1, 0, int(round(-0.2 / 2.0 * MAX_ADC)), 3, 0, 250), trig


def test_not_found_message():
    fake = install_fake()
    fake.ps2000aOpenUnit = lambda ref, serial: PICO_STATUS["PICO_NOT_FOUND"]
    from scope_pico import PicoScope2000A
    s = PicoScope2000A()
    try:
        s.open()
    except RuntimeError as exc:
        assert "PICO_NOT_FOUND" in str(exc) and "PicoScope 6/7" in str(exc) and "--diagnose" in str(exc), exc
    else:
        raise AssertionError("expected RuntimeError")
    s.close()          # must be a harmless no-op after a failed open


def test_missing_driver_message():
    for name in ("picosdk", "picosdk.ps2000a", "picosdk.constants", "scope_pico"):
        sys.modules.pop(name, None)
    sys.modules["picosdk"] = None            # makes `import picosdk...` raise ImportError
    try:
        import scope_pico
        try:
            scope_pico.PicoScope2000A()
        except RuntimeError as exc:
            assert "PicoSDK" in str(exc)
        else:
            raise AssertionError("expected RuntimeError")
    finally:
        sys.modules.pop("picosdk", None)
        sys.modules.pop("scope_pico", None)


def test_symbols_exist_in_real_wrapper():
    src = os.environ.get("PICOSDK_SRC")
    if not src or not Path(src).exists():
        print("  (skipped: set PICOSDK_SRC to a picosdk-python-wrappers checkout)")
        return
    wrapper = (Path(src) / "picosdk" / "ps2000a.py").read_text(encoding="utf-8")
    consts = (Path(src) / "picosdk" / "constants.py").read_text(encoding="utf-8")
    code = (ROOT / "scope_pico.py").read_text(encoding="utf-8")
    funcs = set(re.findall(r"\bps\.(ps2000a\w+)", code))
    assert funcs, "no driver calls found"
    for fn in sorted(funcs):
        assert '"%s"' % fn in wrapper, "driver function not in wrapper: " + fn
    for sym in sorted(set(re.findall(r'"(PS2000A_\w+)"', code))):
        if sym in ("PS2000A_RISING", "PS2000A_FALLING"):
            assert re.search(r"\b%s\b" % sym.lower(), wrapper), "direction missing: " + sym
        else:
            assert ('"%s"' % sym in wrapper) or ("'%s'" % sym in wrapper), "enum entry not in wrapper: " + sym
    for key in sorted(set(re.findall(r'self\._status\["(PICO_\w+)"\]', code))):
        assert '"%s"' % key in consts, "status code not in constants: " + key
    print("  checked %d driver functions against the real wrapper" % len(funcs))


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("PASS", t.__name__)
    print("ALL %d PASSED" % len(tests))
