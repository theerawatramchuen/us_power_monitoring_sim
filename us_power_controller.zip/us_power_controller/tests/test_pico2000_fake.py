"""Exercises scope_pico2000.PicoScope2000 (legacy ps2000 API, PicoScope 2204A) against a fake `picosdk.ps2000`.

Proves our call sequence / scaling; cannot prove the real ps2000.dll behaves like the fake.
Set PICOSDK_SRC to a picosdk-python-wrappers checkout to also verify every driver symbol exists in the wrapper.
Run:  python tests/test_pico2000_fake.py
"""
import ctypes, os, re, sys, types
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


class FakePs2000:
    def __init__(self, max_samples=4000):
        self.calls, self.max_samples = [], max_samples

    def ps2000_open_unit(self): self.calls.append(("open",)); return 7
    def ps2000_get_unit_info(self, h, buf, n, line):
        buf.value = b"2204A" if line == 3 else b"13239/2532"; return 5
    def ps2000_set_channel(self, h, ch, en, dc, rng): self.calls.append(("chan", ch, en, dc, rng)); return 1
    def ps2000_get_timebase(self, h, tb, n, interval, units, over, maxs):
        # timebase k -> 10 ns * 2**k ; units ns (2) or us(3) when large
        ns = 10 * 2 ** tb
        if ns >= 100000: interval._obj.value, units._obj.value = ns // 1000, 3
        else: interval._obj.value, units._obj.value = ns, 2
        maxs._obj.value = self.max_samples
        return 1
    def ps2000_set_trigger2(self, h, src, thr, d, delay, auto): self.calls.append(("trig", src, thr, d, delay, auto)); return 1
    def ps2000_run_block(self, h, n, tb, over, ind): self.calls.append(("run", n, tb)); return 1
    def ps2000_ready(self, h): return 1
    def ps2000_get_values(self, h, a, b, c, d, ovf, n):
        t = np.arange(n)
        A = (0.5 / 2.0 * 32767 * np.sin(t / 7.0)).astype(np.int16)
        B = np.clip(5.2 / 5.0 * 32767 * np.sin(t / 7.0), -32767, 32767).astype(np.int16)
        ctypes.memmove(a, A.ctypes.data, n * 2); ctypes.memmove(b, B.ctypes.data, n * 2)
        ovf._obj.value = 0b10
        return n
    def ps2000_set_sig_gen_arbitrary(self, h, off, pk, p0, p1, inc, dwell, wf, n, sweep, sweeps):
        self.calls.append(("awg", off.value, pk.value, p0.value, n.value)); return 1
    def ps2000_stop(self, h): return 1
    def ps2000_close_unit(self, h): self.calls.append(("close",)); return 1


def install(max_samples=4000):
    fake = FakePs2000(max_samples)
    pkg, mod = types.ModuleType("picosdk"), types.ModuleType("picosdk.ps2000")
    mod.ps2000 = fake
    sys.modules.update({"picosdk": pkg, "picosdk.ps2000": mod})
    sys.modules.pop("scope_pico2000", None)
    return fake


def cfg(**o):
    from config import validate_scope
    return validate_scope(o)


def test_configure_and_read():
    fake = install()
    from scope_pico2000 import PicoScope2000
    from common import scale_capture
    s = PicoScope2000()
    assert s.open() == {"model": "PicoScope 2204A", "serial": "13239/2532"}
    c = cfg()
    a = s.configure(c)
    # 100 ms: finest step with <=4000 samples is 40.96 us (tb 12) -> 2441 samples
    assert a["timebase"] == 12 and a["samples"] == 2441 and abs(a["dt"] - 40.96e-6) < 1e-9, a
    trig = [x for x in fake.calls if x[0] == "trig"][-1]
    assert trig[:4] == ("trig", 1, int(round(0.5 / 5.0 * 32767)), 0) and trig[4] == -2.0 and trig[5] == 0, trig
    assert [x for x in fake.calls if x[0] == "chan"] == [("chan", 0, 1, 0, 7), ("chan", 1, 1, 0, 8)]
    s.arm()
    assert [x for x in fake.calls if x[0] == "run"][-1] == ("run", 2441, 12)
    assert s.is_ready()
    raw = s.read()
    assert raw.ch1_v.size == 2441 and abs(float(raw.ch1_v.max()) - 0.5) < 0.01
    assert raw.flags["clip_ch2"] and raw.flags["overflow_ch2"] and not raw.flags["clip_ch1"], raw.flags
    f = scale_capture(raw, c, 1, 0.0)
    assert abs(float(f.current_a.max()) - 0.1) < 0.003 and abs(float(f.voltage_v.max()) - 50) < 0.5
    s.close()
    assert fake.calls[-1] == ("close",)


def test_memory_cap_and_short_window():
    install(max_samples=2000)
    from scope_pico2000 import PicoScope2000
    s = PicoScope2000(); s.open()
    assert s.configure(cfg())["samples"] <= 2000
    a = s.configure(cfg(capture_window_ms=1.0))
    assert 100 <= a["samples"] <= 2000 and abs(a["window_s"] - 1e-3) < 2e-5, a


def test_10mv_snaps_and_trigger_none():
    fake = install()
    from scope_pico2000 import PicoScope2000
    s = PicoScope2000(); s.open()
    s.configure(cfg(ch1={"range_v": 0.01}, trigger={"source": "NONE"}))
    assert [x for x in fake.calls if x[0] == "chan"][-2][4] == 1        # 20 mV
    assert [x for x in fake.calls if x[0] == "trig"][-1][1] == 5        # PS2000_NONE


def test_awg_started_once():
    fake = install()
    from scope_pico2000 import PicoScope2000
    s = PicoScope2000(); s.open()
    c = cfg(awg={"enabled": True, "csv": "tek0001.csv"})
    s.configure(c); s.configure(c)
    awg = [x for x in fake.calls if x[0] == "awg"]
    assert len(awg) == 1 and awg[0][4] == 4096 and awg[0][3] == 1092 and 520000 < awg[0][2] < 540000, awg
    s.close(); s.open(); s.configure(c)
    assert len([x for x in fake.calls if x[0] == "awg"]) == 2


def test_open_failures():
    fake = install()
    from scope_pico2000 import PicoScope2000
    for val, word in ((0, "No PicoScope"), (-1, "in use")):
        fake.ps2000_open_unit = lambda v=val: v
        try: PicoScope2000().open()
        except RuntimeError as e: assert word in str(e), e
        else: raise AssertionError


def test_auto_falls_back():
    install()
    sys.modules["picosdk.ps2000a"] = None            # ps2000a unavailable
    fake = sys.modules["picosdk.ps2000"].ps2000
    fake.ps2000_open_unit = lambda: 0                # ps2000 finds nothing
    sys.modules.pop("scope_pico", None); sys.modules.pop("scope_auto", None)
    from scope_auto import AutoScope
    try: AutoScope().open()
    except RuntimeError as e: assert "ps2000:" in str(e) and "ps2000a:" in str(e), e
    else: raise AssertionError
    fake.ps2000_open_unit = lambda: 5
    sc = AutoScope(); info = sc.open()
    assert info["driver"] == "ps2000" and info["model"] == "PicoScope 2204A"
    sys.modules.pop("picosdk.ps2000a", None)


def test_symbols_exist_in_real_wrapper():
    src = os.environ.get("PICOSDK_SRC")
    if not src or not Path(src).exists():
        print("  (skipped: set PICOSDK_SRC)"); return
    wrapper = (Path(src) / "picosdk" / "ps2000.py").read_text(encoding="utf-8")
    code = (ROOT / "scope_pico2000.py").read_text(encoding="utf-8")
    funcs = set(re.findall(r"\bps\.(ps2000_\w+)", code))
    assert funcs
    for fn in sorted(funcs):
        assert '"%s"' % fn in wrapper, fn
    # range enum values must match the wrapper's table
    for name, val in re.findall(r"'(PS2000_\w+MV|PS2000_\w+V)':\s*(\d+)", wrapper):
        pass
    print("  checked %d driver functions against the real wrapper" % len(funcs))


if __name__ == "__main__":
    ts = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in ts:
        t(); print("PASS", t.__name__)
    print("ALL %d PASSED" % len(ts))
