"""Built-in simulated scope (run the controller with --simulate).

Produces one ultrasonic bonding burst every 0.6-1.4 s: a 20 ms ramp up, steady state, 20 ms ramp down,
with an occasional high-power or low-power bond so the alarm path can be exercised without hardware.
The signals are generated in engineering units and converted back to *scope-input volts* (through the
configured CT1 sensitivity and probe ratio, with 8-bit quantisation and clipping) so the whole scaling
path is the same as for real hardware.
"""
from __future__ import annotations

import random
import time

import numpy as np

from common import ScopeRaw

V_PEAK = 20.0        # volts at the transducer
I_PEAK = 0.17        # amperes
PHASE = 0.5          # rad, current lags voltage
CARRIER_HZ = 59370.0  # deliberately not a sub-multiple of the sample rate


class SimScope:
    model = "Simulated PicoScope 2204A"

    def __init__(self) -> None:
        self._cfg = None
        self._due = 0.0
        self._n = 0
        self._dt = 0.0
        self._pre = 0

    def open(self) -> dict:
        return {"model": self.model, "serial": "SIM00/000"}

    def configure(self, cfg: dict) -> dict:
        self._cfg = cfg
        n = int(cfg["samples"])
        dt = max(1, round(cfg["capture_window_ms"] / 1000.0 / n / 8e-9)) * 8e-9   # 8 ns granularity
        self._n, self._dt = n, dt
        self._pre = int(round(n * cfg["pre_trigger_pct"] / 100.0))
        return {"dt": dt, "samples": n, "pre_samples": self._pre, "post_samples": n - self._pre,
                "window_s": n * dt, "timebase": int(round(dt * 125e6)) + 2, "sample_rate": 1.0 / dt,
                "samples_requested": n}

    def arm(self) -> None:
        self._due = time.monotonic() + random.uniform(0.6, 1.4)

    def is_ready(self) -> bool:
        return time.monotonic() >= self._due

    def stop(self) -> None:
        pass

    def close(self) -> None:
        pass

    @staticmethod
    def _envelope(t: np.ndarray) -> np.ndarray:
        return np.clip(np.minimum(t / 0.020, (0.100 - t) / 0.020), 0.0, 1.0)

    def read(self) -> ScopeRaw:
        cfg = self._cfg
        t = (np.arange(self._n) - self._pre) * self._dt
        roll = random.random()
        gain = 1.25 if roll < 0.12 else 0.70 if roll < 0.22 else 1.0 + random.uniform(-0.03, 0.03)
        env = self._envelope(t)
        f = CARRIER_HZ + random.uniform(-200.0, 200.0)
        ph = random.uniform(0.0, 6.2832)
        v_phys = V_PEAK * env * np.sin(6.2832 * f * t + ph) + np.random.normal(0, 0.02, t.size)
        i_phys = I_PEAK * gain * env * np.sin(6.2832 * f * t + ph - PHASE) + np.random.normal(0, 0.002, t.size)

        c1, c2 = cfg["ch1"], cfg["ch2"]
        s1 = -1.0 if c1["invert"] else 1.0
        s2 = -1.0 if c2["invert"] else 1.0
        flags, out = {}, []
        for idx, (volts, rng) in enumerate(((i_phys * c1["volts_per_amp"] * s1, c1["range_v"]),
                                            (v_phys / c2["probe_ratio"] * s2, c2["range_v"])), start=1):
            counts = np.clip(np.round(volts / rng * 127.0), -127, 127)       # 8-bit converter
            flags["clip_ch%d" % idx] = bool(np.abs(counts).max() >= 0.97 * 127)
            flags["overflow_ch%d" % idx] = False
            out.append((counts / 127.0 * rng).astype(np.float32))
        return ScopeRaw(t0=-self._pre * self._dt, dt=self._dt, ch1_v=out[0], ch2_v=out[1], flags=flags)
