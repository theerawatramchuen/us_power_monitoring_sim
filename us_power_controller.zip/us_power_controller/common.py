"""Data types shared by the scope drivers, the acquisition thread and the server."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class ScopeRaw:
    """One capture exactly as the scope delivered it: volts at the scope input."""
    t0: float                  # time of first sample relative to the trigger point (s, <= 0 with pre-trigger)
    dt: float                  # sample interval (s)
    ch1_v: np.ndarray          # CH1 (CT1 output) in volts at the scope input
    ch2_v: np.ndarray          # CH2 (voltage probe output) in volts at the scope input
    flags: dict = field(default_factory=dict)   # clip_ch1/clip_ch2/overflow_ch1/overflow_ch2


@dataclass
class Frame:
    """A capture converted to engineering units."""
    seq: int
    wall_time: float           # time.time() when the capture was read
    t0: float
    dt: float
    current_a: np.ndarray      # float32, amperes
    voltage_v: np.ndarray      # float32, volts at the measured circuit
    flags: dict = field(default_factory=dict)


def scale_capture(raw: ScopeRaw, scope_cfg: dict, seq: int, wall_time: float) -> Frame:
    """Apply CT1 sensitivity and voltage-probe ratio.

    current [A] = CH1 volts / (volts per amp)       (CT1 = 5 V/A into 50 ohm)
    voltage [V] = CH2 volts * probe ratio
    """
    c1, c2 = scope_cfg["ch1"], scope_cfg["ch2"]
    sign1 = -1.0 if c1["invert"] else 1.0
    sign2 = -1.0 if c2["invert"] else 1.0
    current = (raw.ch1_v.astype(np.float64) * (sign1 / c1["volts_per_amp"])).astype(np.float32)
    voltage = (raw.ch2_v.astype(np.float64) * (sign2 * c2["probe_ratio"])).astype(np.float32)
    return Frame(seq=seq, wall_time=wall_time, t0=raw.t0, dt=raw.dt,
                 current_a=current, voltage_v=voltage, flags=dict(raw.flags))
