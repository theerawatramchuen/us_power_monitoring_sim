"""Play a DSO capture (TIME,CH1 csv) from the PicoScope 2204A signal-generator (AWG) output.

    python awg_play.py tek0001.csv            # plays until Ctrl+C
    python awg_play.py tek0001.csv --dry-run  # only shows what would be played (no scope needed)

How the file is turned into the AWG buffer
  * The 2204A AWG has a 4096-sample, 8-bit buffer and an output range of +/-2 V (600 ohm source impedance).
  * The active burst of the capture (where the signal leaves the noise floor, plus a margin) is cut out and
    played at the CSV's own sample interval, so it lasts as long as in the capture; the buffer is padded with the
    baseline to 4096 samples, so the burst repeats every 4096 x interval (e.g. 81.9 ms for 20 us samples).
  * Amplitude in volts is the CSV's CH1 value (volts at the DSO input), so the output has the same voltage as the
    DSO saw.  --scale multiplies it.
Limits: values are quantised to 8 bits; if the burst is longer than 4096 samples it is decimated (a warning is shown).
Close the controller (app.py) and PicoScope 6/7 first - only one program can hold the scope.
"""
from __future__ import annotations

import argparse
import math
import sys

import numpy as np

BUFFER = 4096
DDS_CLOCK = 48_000_000.0       # from Pico's ps2000SigGen.py example


def load(path: str):
    d = np.genfromtxt(path, delimiter=",", skip_header=1, usecols=(0, 1))
    return d[:, 0], d[:, 1]


def build(t, y, scale=1.0, margin=20, threshold=None):
    dt = float(np.median(np.diff(t)))
    if y.size <= BUFFER:                      # already fits the AWG memory: play it exactly as it is
        buf = np.full(BUFFER, float(y[-1]))
        buf[:y.size] = y * scale
        buf[y.size:] = buf[y.size - 1]
        return buf, dt, float(y[0]) * scale, (0, y.size), ""
    base = float(np.median(y))
    noise = float(np.median(np.abs(y - base)))      # robust: the burst may fill much of the record
    thr = threshold if threshold is not None else max(6 * noise, 0.08 * float(np.max(np.abs(y - base))))
    idx = np.where(np.abs(y - base) > thr)[0]
    if idx.size == 0:
        raise SystemExit("No burst found above the noise floor in this file.")
    a, b = max(idx[0] - margin, 0), min(idx[-1] + margin + 1, y.size)
    seg = (y[a:b] - base) * scale
    warn = ""
    if seg.size > BUFFER:
        step = math.ceil(seg.size / BUFFER)
        seg, dt = seg[::step], dt * step
        warn = "burst longer than %d samples: decimated by %d (aliasing possible)" % (BUFFER, step)
    buf = np.zeros(BUFFER)
    buf[:seg.size] = seg
    return buf, dt, base * scale, (a, b), warn


def to_awg(buf):
    lo, hi = float(buf.min()), float(buf.max())
    span = max(hi - lo, 1e-6)
    u8 = np.round((buf - lo) / span * 255).astype(np.uint8)
    pk_uv = int(round(span * 1e6))
    off_uv = int(round((hi + lo) / 2 * 1e6))
    return u8, pk_uv, off_uv


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("csv")
    ap.add_argument("--scale", type=float, default=1.0, help="amplitude multiplier (default 1)")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)

    t, y = load(a.csv)
    buf, dt, base, (i0, i1), warn = build(t, y, a.scale)
    u8, pk_uv, off_uv = to_awg(buf)
    rep_hz = 1.0 / (BUFFER * dt)
    phase = int(((rep_hz * BUFFER) / 4096) * (2 ** 32) / DDS_CLOCK)
    peak = float(np.max(np.abs(buf)))
    print("Burst: samples %d..%d (t = %.4g .. %.4g s), %d samples at %.4g us" % (i0, i1, t[i0], t[i1 - 1], i1 - i0, dt * 1e6))
    print("Output: %.3f V peak around %.3f V offset (%.3f V p-p), repeats every %.1f ms (%.3f Hz), phase word %d"
          % (peak, off_uv / 1e6, pk_uv / 1e6, 1e3 / rep_hz, rep_hz, phase))
    if warn:
        print("WARNING:", warn)
    if max(abs(off_uv) + pk_uv / 2, 0) > 2_000_000:
        raise SystemExit("Output would exceed the +/-2 V range of the 2204A generator; lower --scale.")
    if a.dry_run:
        return 0

    import ctypes
    from picosdk.ps2000 import ps2000 as ps
    h = ps.ps2000_open_unit()
    if h <= 0:
        raise SystemExit("Could not open the PicoScope (close app.py / PicoScope 6/7 first).")
    try:
        ok = ps.ps2000_set_sig_gen_arbitrary(
            h, ctypes.c_int32(off_uv), ctypes.c_uint32(pk_uv), ctypes.c_uint32(phase), ctypes.c_uint32(phase),
            ctypes.c_uint32(0), ctypes.c_uint32(0), u8.ctypes.data_as(ctypes.c_void_p), ctypes.c_int32(BUFFER),
            0, ctypes.c_uint32(0))
        if ok == 0:
            raise SystemExit("The scope rejected the arbitrary-waveform settings.")
        print("AWG output running on the scope's generator BNC. Press Ctrl+C to stop.")
        try:
            while True:
                import time
                time.sleep(0.5)
        except KeyboardInterrupt:
            pass
    finally:
        ps.ps2000_close_unit(h)
    return 0


if __name__ == "__main__":
    sys.exit(main())
