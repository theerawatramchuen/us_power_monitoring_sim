"""PicoScope 2000 Series (A API) block-mode driver - written for the PicoScope 2204A.

Uses Pico's official `picosdk` Python wrapper (pip install picosdk) which in turn
needs the PicoSDK / PicoScope 7 driver package installed on the PC (it provides
ps2000a.dll).  The call sequence follows Pico's ps2000aBlockExample.py.

Capture model (same as the 1000-point DSO exports this project started from):
one triggered block of N samples per channel, both channels sampled
simultaneously.  The 2204A has 8 kS of memory shared by the two channels, so
about 4000 samples per channel is the practical maximum.
"""
from __future__ import annotations

import ctypes
import time

import numpy as np

from common import ScopeRaw
from config import RANGES_V

_RANGE_NAMES = [
    "PS2000A_10MV", "PS2000A_20MV", "PS2000A_50MV", "PS2000A_100MV", "PS2000A_200MV",
    "PS2000A_500MV", "PS2000A_1V", "PS2000A_2V", "PS2000A_5V", "PS2000A_10V", "PS2000A_20V",
]
_PICO_INFO_VARIANT = 3          # PICO_VARIANT_INFO
_PICO_INFO_SERIAL = 4           # PICO_BATCH_AND_SERIAL
_CLIP_FRACTION = 0.97           # report clipping when a sample reaches 97 % of full scale


def _load_sdk():
    try:
        from picosdk.ps2000a import ps2000a as ps
        from picosdk.constants import PICO_STATUS, PICO_STATUS_LOOKUP
    except Exception as exc:    # ImportError, or OSError when ps2000a.dll cannot be found
        raise RuntimeError(
            "The PicoScope driver could not be loaded (%s). Install the 'picosdk' Python package "
            "(pip install picosdk) AND the 64-bit PicoSDK or PicoScope 7 software from picotech.com "
            "so that ps2000a.dll is present. Python and the driver must both be 64-bit." % exc
        ) from exc
    return ps, PICO_STATUS, PICO_STATUS_LOOKUP


class PicoScope2000A:
    model = "PicoScope 2000A"

    def __init__(self) -> None:
        self.ps, self._status, self._lookup = _load_sdk()
        self.handle = ctypes.c_int16()
        self.opened = False
        self.max_adc = 32512
        self._cfg: dict | None = None
        self._bufs: list[np.ndarray] = []
        self._ready = ctypes.c_int16(0)
        self._pre = self._post = self._n = 0
        self._timebase = 0
        self._dt = 0.0
        self._range_v = (1.0, 1.0)

    # ------------------------------------------------------------------ helpers
    def _name(self, code: int) -> str:
        return self._lookup.get(code, hex(code))

    def _check(self, what: str, code: int) -> None:
        if code != self._status["PICO_OK"]:
            raise RuntimeError("PicoScope %s failed: %s" % (what, self._name(code)))

    def _unit_info(self, info: int) -> str:
        buf = ctypes.create_string_buffer(64)
        need = ctypes.c_int16()
        code = self.ps.ps2000aGetUnitInfo(self.handle, buf, 64, ctypes.byref(need), info)
        return buf.value.decode("ascii", "ignore") if code == self._status["PICO_OK"] else ""

    # --------------------------------------------------------------------- open
    def open(self) -> dict:
        code = self.ps.ps2000aOpenUnit(ctypes.byref(self.handle), None)
        if code == self._status["PICO_NOT_FOUND"]:
            raise RuntimeError(
                "No PicoScope could be opened (driver status PICO_NOT_FOUND). The driver itself loaded fine. "
                "Most common cause: PicoScope 6/7 is running and holds the scope (it starts by itself when the scope is "
                "plugged in) - close it completely, including the system tray. Otherwise check the USB cable and use a "
                "direct USB port. Run 'python app.py --diagnose' to see exactly what Windows and the driver report.")
        self._check("OpenUnit", code)
        self.opened = True
        max_adc = ctypes.c_int16()
        self._check("MaximumValue", self.ps.ps2000aMaximumValue(self.handle, ctypes.byref(max_adc)))
        self.max_adc = max_adc.value
        variant = self._unit_info(_PICO_INFO_VARIANT) or "2000A"
        self.model = "PicoScope " + variant
        return {"model": self.model, "serial": self._unit_info(_PICO_INFO_SERIAL)}

    # ---------------------------------------------------------------- configure
    def _find_timebase(self, n: int, target_dt: float):
        """Return (timebase, actual_dt_seconds, n) closest to the requested interval.

        Timebase n >= 3 on the 2000A series is (n - 2) / 125 MHz, but the driver is asked for the
        real interval of every candidate, so the actual value always comes from the instrument.
        """
        invalid = self._status["PICO_INVALID_TIMEBASE"]
        tb = max(1, int(round(target_dt * 125e6)) + 2)
        for attempt in range(30):
            interval_ns = ctypes.c_float()
            max_samples = ctypes.c_int32()
            code = self.ps.ps2000aGetTimebase2(self.handle, tb, n, ctypes.byref(interval_ns), 0,
                                               ctypes.byref(max_samples), 0)
            if code == self._status["PICO_OK"]:
                if 0 < max_samples.value < n:
                    n = int(max_samples.value)            # memory shared between channels
                    continue
                actual = interval_ns.value * 1e-9
                if abs(actual - target_dt) <= 0.02 * target_dt or attempt >= 12:
                    return tb, actual, n
                tb = max(0, int(round((tb - 2) * target_dt / actual)) + 2) if tb >= 3 else tb + 1
            elif code == invalid:
                tb += 1
            else:
                n = max(100, int(n * 0.8))                # probably too many samples for this timebase
        raise RuntimeError("Could not find a valid PicoScope timebase for %.3g s per sample" % target_dt)

    def configure(self, cfg: dict) -> dict:
        ps = self.ps
        self.stop()
        self._cfg = cfg
        chan = [ps.PS2000A_CHANNEL["PS2000A_CHANNEL_A"], ps.PS2000A_CHANNEL["PS2000A_CHANNEL_B"]]
        ranges = []
        for idx, key in enumerate(("ch1", "ch2")):
            c = cfg[key]
            rng = RANGES_V.index(c["range_v"])
            ranges.append(c["range_v"])
            coupling = ps.PS2000A_COUPLING["PS2000A_AC" if c["coupling"] == "AC" else "PS2000A_DC"]
            self._check("SetChannel %s" % key, ps.ps2000aSetChannel(
                self.handle, chan[idx], 1, coupling, ps.PS2000A_RANGE[_RANGE_NAMES[rng]], 0.0))
        self._range_v = (ranges[0], ranges[1])

        trig = cfg["trigger"]
        if trig["source"] == "NONE":
            self._check("SetSimpleTrigger", ps.ps2000aSetSimpleTrigger(self.handle, 0, 0, 0, 2, 0, 0))
        else:
            src = 0 if trig["source"] == "CH1" else 1
            counts = int(round(trig["level_v"] / self._range_v[src] * self.max_adc))
            counts = max(-self.max_adc, min(self.max_adc, counts))
            direction = ps.PS2000A_THRESHOLD_DIRECTION[
                "PS2000A_RISING" if trig["direction"] == "RISING" else "PS2000A_FALLING"]
            self._check("SetSimpleTrigger", ps.ps2000aSetSimpleTrigger(
                self.handle, 1, chan[src], counts, direction, 0, int(trig["auto_ms"])))

        n_req = int(cfg["samples"])
        target_dt = cfg["capture_window_ms"] / 1000.0 / n_req
        self._timebase, self._dt, self._n = self._find_timebase(n_req, target_dt)
        self._pre = int(round(self._n * cfg["pre_trigger_pct"] / 100.0))
        self._post = self._n - self._pre
        self._bufs = [np.zeros(self._n, dtype=np.int16), np.zeros(self._n, dtype=np.int16)]
        return {
            "dt": self._dt, "samples": self._n, "pre_samples": self._pre, "post_samples": self._post,
            "window_s": self._n * self._dt, "timebase": self._timebase, "sample_rate": 1.0 / self._dt,
            "samples_requested": n_req,
        }

    # --------------------------------------------------------------- capture
    def arm(self) -> None:
        self._ready = ctypes.c_int16(0)
        self._check("RunBlock", self.ps.ps2000aRunBlock(
            self.handle, self._pre, self._post, self._timebase, 0, None, 0, None, None))

    def is_ready(self) -> bool:
        self._check("IsReady", self.ps.ps2000aIsReady(self.handle, ctypes.byref(self._ready)))
        return self._ready.value != 0

    def read(self) -> ScopeRaw:
        ps = self.ps
        for ch, buf in enumerate(self._bufs):
            self._check("SetDataBuffers", ps.ps2000aSetDataBuffers(
                self.handle, ch, buf.ctypes.data_as(ctypes.POINTER(ctypes.c_int16)), None,
                self._n, 0, ps.PS2000A_RATIO_MODE["PS2000A_RATIO_MODE_NONE"]))
        count = ctypes.c_uint32(self._n)
        overflow = ctypes.c_int16()
        self._check("GetValues", ps.ps2000aGetValues(
            self.handle, 0, ctypes.byref(count), 0, 0, 0, ctypes.byref(overflow)))
        m = int(count.value)
        volts, flags = [], {}
        for ch in (0, 1):
            adc = self._bufs[ch][:m]
            volts.append(adc.astype(np.float32) * np.float32(self._range_v[ch] / self.max_adc))
            clipped = int(np.abs(adc.astype(np.int32)).max()) >= _CLIP_FRACTION * self.max_adc if m else False
            flags["clip_ch%d" % (ch + 1)] = bool(clipped)
            flags["overflow_ch%d" % (ch + 1)] = bool(overflow.value & (1 << ch))
        return ScopeRaw(t0=-self._pre * self._dt, dt=self._dt, ch1_v=volts[0], ch2_v=volts[1], flags=flags)

    def stop(self) -> None:
        if self.opened:
            self.ps.ps2000aStop(self.handle)

    def close(self) -> None:
        if self.opened:
            try:
                self.ps.ps2000aStop(self.handle)
            finally:
                self.ps.ps2000aCloseUnit(self.handle)
                self.opened = False
