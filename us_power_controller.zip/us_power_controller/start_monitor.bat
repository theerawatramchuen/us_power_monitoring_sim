@echo off
rem US Power Monitoring Controller launcher (Windows).
rem First run creates a private Python environment and installs the requirements.
rem Extra arguments are passed on:  start_monitor.bat --simulate   or   start_monitor.bat --selftest
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Creating Python environment...
  py -3 -m venv .venv || (echo Python 3.10 or newer ^(64-bit^) is required. Install it from python.org and try again. & pause & exit /b 1)
  ".venv\Scripts\python.exe" -m pip install --upgrade pip
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt || (echo Package installation failed. & pause & exit /b 1)
)
".venv\Scripts\python.exe" app.py %*
if errorlevel 1 pause
