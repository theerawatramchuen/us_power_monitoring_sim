"""driver = "auto": try the original ps2000 driver first (PicoScope 2204A, 2205A, 2104 ...), then ps2000a."""
from __future__ import annotations

import importlib

_CANDIDATES = (("scope_pico2000", "PicoScope2000", "ps2000"), ("scope_pico", "PicoScope2000A", "ps2000a"))


class AutoScope:
    def __init__(self) -> None:
        self._impl = None
        self.driver = ""

    def open(self) -> dict:
        errors = []
        for module, cls, label in _CANDIDATES:
            impl = None
            try:
                impl = getattr(importlib.import_module(module), cls)()
                info = impl.open()
            except Exception as exc:
                errors.append("%s: %s" % (label, exc))
                if impl is not None:
                    try:
                        impl.close()
                    except Exception:
                        pass
                continue
            self._impl, self.driver = impl, label
            info = dict(info)
            info["driver"] = label
            return info
        raise RuntimeError("No PicoScope could be opened with either driver family. " + " || ".join(errors) +
                           "  (Run 'python app.py --diagnose' for details.)")

    def __getattr__(self, name):                       # configure / arm / is_ready / read / stop / close
        impl = self.__dict__.get("_impl")
        if impl is None:
            raise AttributeError(name)
        return getattr(impl, name)
