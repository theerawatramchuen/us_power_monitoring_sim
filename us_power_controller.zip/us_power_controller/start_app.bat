@echo off
rem Start the US Power Monitoring Controller (same steps as typing them in a command window).
title US Power Monitoring Controller
cd /d "%~dp0"

if not exist "env\Scripts\activate.bat" (
    echo Python environment "env" not found in %CD%.
    echo Create it once with:  python -m venv env ^&^& env\Scripts\activate ^&^& pip install -r requirements.txt
    pause
    exit /b 1
)

call env\Scripts\activate
python app.py %*

echo.
echo The controller has stopped. Press any key to close this window.
pause ^>nul
