"""Acquisition thread: owns the scope, arms it, waits for each trigger, hands scaled frames to the server."""
from __future__ import annotations

import copy
import logging
import threading
import time

from common import Frame, scale_capture

log = logging.getLogger("acquisition")


class Acquisition(threading.Thread):
    """Runs scope I/O off the web server's event loop.

    make_scope()      -> new driver object (PicoScope2000A or SimScope)
    get_scope_cfg()   -> current validated "scope" config section
    on_frame(Frame)   -> called from this thread for every capture
    on_status(dict)   -> called from this thread whenever the status changes
    """

    RETRY_S = 3.0

    def __init__(self, make_scope, get_scope_cfg, on_frame, on_status) -> None:
        super().__init__(daemon=True, name="acquisition")
        self._make_scope = make_scope
        self._get_cfg = get_scope_cfg
        self._on_frame = on_frame
        self._on_status = on_status
        self._stop_evt = threading.Event()
        self._armed = threading.Event()
        self._dirty = threading.Event()
        self._dirty.set()
        self._seq = 0
        self._last_status = None
        self._info: dict = {}
        self._applied: dict = {}
        self._last_error = None

    # --------------------------------------------------------------- public API
    def set_armed(self, run: bool) -> None:
        if run:
            self._armed.set()
        else:
            self._armed.clear()

    @property
    def armed(self) -> bool:
        return self._armed.is_set()

    def reconfigure(self) -> None:
        self._dirty.set()

    def shutdown(self, timeout: float = 5.0) -> None:
        self._stop_evt.set()
        self.join(timeout)

    # ---------------------------------------------------------------- internals
    def _status(self, state: str, message: str = "") -> None:
        st = {
            "state": state, "message": message, "armed": self.armed,
            "model": self._info.get("model", ""), "serial": self._info.get("serial", ""),
            "simulated": bool(self._info.get("simulated")), "applied": self._applied,
        }
        key = (state, message, st["armed"], st["model"], str(self._applied))
        if key != self._last_status:
            self._last_status = key
            self._on_status(st)

    def _sleep(self, seconds: float) -> None:
        self._stop_evt.wait(seconds)

    def run(self) -> None:
        scope = None
        applied_cfg = None
        while not self._stop_evt.is_set():
            try:
                if scope is None:
                    self._status("connecting", "Opening the scope...")
                    scope = self._make_scope()
                    self._info = scope.open()
                    self._info["simulated"] = scope.__class__.__name__ == "SimScope"
                    log.info("Scope opened: %s", self._info)
                    self._last_error = None
                    self._dirty.set()
                if self._dirty.is_set():
                    self._dirty.clear()
                    applied_cfg = copy.deepcopy(self._get_cfg())
                    self._applied = scope.configure(applied_cfg)
                    log.info("Scope configured: %s", self._applied)
                if not self._armed.is_set():
                    self._status("idle", "Monitoring stopped")
                    self._sleep(0.1)
                    continue
                scope.arm()
                self._status("waiting", "Waiting for trigger")
                cancelled = False
                while not scope.is_ready():
                    if self._stop_evt.is_set() or not self._armed.is_set() or self._dirty.is_set():
                        cancelled = True
                        break
                    time.sleep(0.004)
                if cancelled:
                    scope.stop()
                    continue
                raw = scope.read()
                self._seq += 1
                self._on_frame(scale_capture(raw, applied_cfg, self._seq, time.time()))
            except Exception as exc:                      # keep the monitor alive; report and retry
                if str(exc) != self._last_error:          # log a repeating fault once, not every retry
                    log.error("Acquisition error: %s (retrying every %.0f s)", exc, self.RETRY_S)
                    self._last_error = str(exc)
                self._status("error", str(exc))
                if scope is not None:
                    try:
                        scope.close()
                    except Exception:
                        pass
                    scope = None
                self._sleep(self.RETRY_S)
        if scope is not None:
            try:
                scope.close()
            except Exception:
                pass
