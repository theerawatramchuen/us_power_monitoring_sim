"""PicoScope 2000 Series, ORIGINAL 'ps2000' API - for the PicoScope 2204A / 2205A and the older 2000-series models.

(The newer 'ps2000a' API, see scope_pico.py, covers the 2205 MSO and 2206/2207/2208 families but NOT the 2204A.)

Uses Pico's `picosdk` Python wrapper (pip install picosdk) and ps2000.dll from the PicoSDK / PicoScope 7 install.
The call sequence follows Pico's ps2000BlockExample.py: one triggered block of samples on both channels, taken
simultaneously.  The scope's memory (8 kS on the 2204A) is shared by the two channels.
"""
from __future__ import annotations

import ctypes
import logging
from pathlib import Path

import numpy as np

from common import ScopeRaw

# ps2000 input-range enum values (PS2000_20MV = 1 ... PS2000_20V = 10); there is no 10 mV range in this API.
_RANGE_ENUM = {0.02: 1, 0.05: 2, 0.1: 3, 0.2: 4, 0.5: 5, 1.0: 6, 2.0: 7, 5.0: 8, 10.0: 9, 20.0: 10}
_UNIT_SECONDS = {0: 1e-15, 1: 1e-12, 2: 1e-9, 3: 1e-6, 4: 1e-3, 5: 1.0}     # PS2000_FS .. PS2000_S
_NS = 2
_MAX_ADC = 32767              # the driver scales samples to +/-32767 (as in Pico's example)
_CLIP_FRACTION = 0.97
_SRC_NONE = 5                 # PS2000_NONE
_INFO_VARIANT = 3             # ps2000_get_unit_info lines
_INFO_SERIAL = 4
_MIN_SAMPLES = 100


def _load_sdk():
    try:
        from picosdk.ps2000 import ps2000 as ps
    except Exception as exc:        # ImportError, or OSError when ps2000.dll cannot be found
        raise RuntimeError(
            "The PicoScope 'ps2000' driver could not be loaded (%s). Install the 'picosdk' Python package "
            "(pip install picosdk) AND the 64-bit PicoSDK or PicoScope 7 software from picotech.com so that "
            "ps2000.dll is present. Python and the driver must both be 64-bit." % exc
        ) from exc
    return ps


class PicoScope2000:
    model = "PicoScope 2000"

    def __init__(self) -> None:
        self.ps = _load_sdk()
        self.handle = 0
        self._cfg: dict | None = None
        self._bufs: list[np.ndarray] = []
        self._n = self._pre = 0
        self._timebase = 0
        self._dt = 0.0
        self._range_v = (1.0, 1.0)
        self._awg_started = False

    # ------------------------------------------------------------------ helpers
    def _info(self, line: int) -> str:
        buf = ctypes.create_string_buffer(64)
        self.ps.ps2000_get_unit_info(self.handle, buf, 64, line)
        return buf.value.decode("ascii", "ignore").strip()

    def _need(self, what: str, result: int) -> None:
        """Most ps2000 calls return 0 on failure and non-zero on success."""
        if result == 0:
            raise RuntimeError("PicoScope %s failed (the driver returned 0)" % what)

    # --------------------------------------------------------------------- open
    def open(self) -> dict:
        handle = self.ps.ps2000_open_unit()
        if handle == 0:
            raise RuntimeError(
                "No PicoScope found by the ps2000 driver. Check the USB cable and that PicoScope 6/7 is closed.")
        if handle < 0:
            raise RuntimeError(
                "A PicoScope was found but could not be opened (ps2000_open_unit returned -1). It is most likely "
                "in use by another program - close PicoScope 6/7 completely, including the system tray.")
        self.handle = handle
        variant = self._info(_INFO_VARIANT)
        self.model = "PicoScope " + variant if variant else "PicoScope 2000"
        return {"model": self.model, "serial": self._info(_INFO_SERIAL)}

    # ---------------------------------------------------------------- configure
    def _choose_timebase(self, window_s: float, n_max: int):
        """Finest timebase whose sample interval still covers the whole window within the memory limit.

        Timebases on this API are coarse (the 2000 series steps are powers of two), so the number of samples is
        derived from the window: n = window / interval.  The driver reports every interval itself.
        """
        last = None
        tried = []
        counts = sorted({n_max, 2000, 1000, 500, 100}, reverse=True)
        for tb in range(0, 41):
            hit = None
            for ask in [c for c in counts if c <= n_max] or [n_max]:
                interval = ctypes.c_int32()
                units = ctypes.c_int16(_NS)
                max_samples = ctypes.c_int32()
                ok = self.ps.ps2000_get_timebase(self.handle, tb, ask, ctypes.byref(interval), ctypes.byref(units),
                                                 1, ctypes.byref(max_samples))
                if ok != 0 and interval.value > 0:
                    hit = (interval.value, units.value, max_samples.value)
                    break
            if hit is None:
                tried.append(tb)
                continue
            dt = hit[0] * _UNIT_SECONDS.get(hit[1], 1e-9)
            limit = min(n_max, hit[2]) if hit[2] > 0 else n_max
            n = int(round(window_s / dt))
            last = (tb, dt, limit)
            if n < _MIN_SAMPLES:
                return tb, dt, _MIN_SAMPLES
            if n <= limit:
                return tb, dt, n
        if last is None:
            raise RuntimeError("The PicoScope reports no valid timebase (ps2000_get_timebase returned 0 for timebases %s with up to %d samples; handle=%s)" % (tried, n_max, self.handle))
        tb, dt, limit = last                          # window longer than the memory can hold at the slowest step
        return tb, dt, limit

    def _start_awg(self, awg: dict) -> None:
        """Play a DSO csv on the generator output (test signal).  Done once per opened scope."""
        import awg_play
        path = Path(awg["csv"])
        if not path.is_absolute():
            path = Path(__file__).resolve().parent / path
        if not path.exists():
            raise RuntimeError("awg.csv not found: %s" % path)
        t, y = awg_play.load(str(path))
        buf, dt, _base, _seg, _warn = awg_play.build(t, y, awg["scale"])
        u8, pk_uv, off_uv = awg_play.to_awg(buf)
        if abs(off_uv) + pk_uv / 2 > 2_000_000:
            raise RuntimeError("awg.scale too large: output would exceed the +/-2 V generator range")
        rep_hz = 1.0 / (awg_play.BUFFER * dt)
        phase = int(rep_hz * (2 ** 32) / awg_play.DDS_CLOCK)
        self._awg_buf = u8                               # keep the buffer alive while the generator runs
        ok = self.ps.ps2000_set_sig_gen_arbitrary(
            self.handle, ctypes.c_int32(off_uv), ctypes.c_uint32(pk_uv), ctypes.c_uint32(phase),
            ctypes.c_uint32(phase), ctypes.c_uint32(0), ctypes.c_uint32(0),
            u8.ctypes.data_as(ctypes.c_void_p), ctypes.c_int32(awg_play.BUFFER), 0, ctypes.c_uint32(0))
        self._need("set_sig_gen_arbitrary", ok)
        self._awg_started = True
        logging.getLogger("acquisition").info("AWG test signal started: %s, %.3f V p-p, repeats every %.1f ms",
                                              path.name, pk_uv / 1e6, 1e3 / rep_hz)

    def configure(self, cfg: dict) -> dict:
        ps = self.ps
        self.stop()
        self._cfg = cfg
        if cfg.get("awg", {}).get("enabled") and not self._awg_started:
            self._start_awg(cfg["awg"])
        ranges = []
        for idx, key in enumerate(("ch1", "ch2")):
            c = cfg[key]
            rng = 0.02 if c["range_v"] < 0.02 else c["range_v"]      # no 10 mV range on this API
            enum = _RANGE_ENUM.get(rng)
            if enum is None:
                raise RuntimeError("%s range +/-%g V is not available on this scope (ps2000 supports +/-20 mV to +/-20 V)"
                                   % (key.upper(), c["range_v"]))
            self._need("set_channel %s" % key, ps.ps2000_set_channel(
                self.handle, idx, 1, 1 if c["coupling"] == "DC" else 0, enum))
            ranges.append(rng)
        self._range_v = (ranges[0], ranges[1])

        window_s = cfg["capture_window_ms"] / 1000.0
        self._timebase, self._dt, self._n = self._choose_timebase(window_s, int(cfg["samples"]))
        self._pre = int(round(self._n * cfg["pre_trigger_pct"] / 100.0))

        trig = cfg["trigger"]
        if trig["source"] == "NONE":
            self._need("set_trigger", ps.ps2000_set_trigger2(self.handle, _SRC_NONE, 0, 0, 0.0, 0))
        else:
            src = 0 if trig["source"] == "CH1" else 1
            counts = int(round(trig["level_v"] / self._range_v[src] * _MAX_ADC))
            counts = max(-_MAX_ADC, min(_MAX_ADC, counts))
            direction = 0 if trig["direction"] == "RISING" else 1          # PS2000_RISING / PS2000_FALLING
            # delay is a percentage of the block; a negative value places the trigger point inside the block
            # (pre-trigger data).  -pre_trigger_pct puts the trigger pre_trigger_pct % of the way in.
            self._need("set_trigger", ps.ps2000_set_trigger2(
                self.handle, src, counts, direction, -float(cfg["pre_trigger_pct"]), min(int(trig["auto_ms"]), 32767)))

        self._bufs = [np.zeros(self._n, dtype=np.int16), np.zeros(self._n, dtype=np.int16)]
        return {
            "dt": self._dt, "samples": self._n, "pre_samples": self._pre, "post_samples": self._n - self._pre,
            "window_s": self._n * self._dt, "timebase": self._timebase, "sample_rate": 1.0 / self._dt,
            "samples_requested": int(cfg["samples"]),
        }

    # --------------------------------------------------------------- capture
    def arm(self) -> None:
        indisposed = ctypes.c_int32()
        self._need("run_block", self.ps.ps2000_run_block(
            self.handle, self._n, self._timebase, 1, ctypes.byref(indisposed)))

    def is_ready(self) -> bool:
        r = self.ps.ps2000_ready(self.handle)
        if r < 0:
            raise RuntimeError("PicoScope ps2000_ready reported an error - was the scope unplugged?")
        return r > 0

    def read(self) -> ScopeRaw:
        overflow = ctypes.c_int16()
        got = self.ps.ps2000_get_values(
            self.handle,
            self._bufs[0].ctypes.data_as(ctypes.c_void_p), self._bufs[1].ctypes.data_as(ctypes.c_void_p),
            None, None, ctypes.byref(overflow), self._n)
        if got <= 0:
            raise RuntimeError("PicoScope get_values returned no data")
        m = int(min(got, self._n))
        volts, flags = [], {}
        for ch in (0, 1):
            adc = self._bufs[ch][:m]
            volts.append(adc.astype(np.float32) * np.float32(self._range_v[ch] / _MAX_ADC))
            flags["clip_ch%d" % (ch + 1)] = bool(int(np.abs(adc.astype(np.int32)).max()) >= _CLIP_FRACTION * _MAX_ADC)
            flags["overflow_ch%d" % (ch + 1)] = bool(overflow.value & (1 << ch))
        return ScopeRaw(t0=-self._pre * self._dt, dt=self._dt, ch1_v=volts[0], ch2_v=volts[1], flags=flags)

    def stop(self) -> None:
        if self.handle > 0:
            self.ps.ps2000_stop(self.handle)

    def close(self) -> None:
        if self.handle > 0:
            try:
                self.ps.ps2000_stop(self.handle)
            finally:
                self.ps.ps2000_close_unit(self.handle)
                self.handle = 0
                self._awg_started = False
