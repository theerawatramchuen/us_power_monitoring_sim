#!/usr/bin/env python3
"""US Power Monitoring Controller - PicoScope 2204A (CH1 = Tektronix CT1 current probe, CH2 = AC voltage).

Starts the acquisition thread and a small web server.  Open http://127.0.0.1:8080 (a browser opens
automatically) to see the Ultrasonic Power Monitoring screen with live data.

    python app.py                 # real PicoScope
    python app.py --simulate      # no hardware: built-in simulated scope
    python app.py --selftest      # open the scope, capture once, print a commissioning report
"""
from __future__ import annotations

import argparse
import asyncio
import csv
import json
import logging
import logging.handlers
import struct
import sys
import time
import webbrowser
from collections import OrderedDict
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

import numpy as np
from aiohttp import web

from acquisition import Acquisition
from common import Frame
from config import RANGES_V, atomic_write_text, deep_merge, load_config, save_config, validate_scope

VERSION = "1.0.0"
APP_DIR = Path(__file__).resolve().parent
LEGACY_CH1_SCALE = 0.1      # plot_waveform*.py multiply the CH1 column by 0.1 to get amperes
log = logging.getLogger("controller")


def make_scope(driver: str):
    if driver == "sim":
        from scope_sim import SimScope
        return SimScope()
    if driver == "ps2000a":
        from scope_pico import PicoScope2000A
        return PicoScope2000A()
    if driver == "ps2000":
        from scope_pico2000 import PicoScope2000
        return PicoScope2000()
    if driver == "tbs1000c":
        from scope_tek import TekTBS1000C
        return TekTBS1000C()
    from scope_auto import AutoScope
    return AutoScope()


def encode_frame(f: Frame) -> bytes:
    """Binary WebSocket message: u32 header length, JSON header (space padded to 4 bytes), f32 current, f32 voltage."""
    header = {"type": "frame", "seq": f.seq, "ts": int(f.wall_time * 1000), "t0": f.t0, "dt": f.dt,
              "n": int(f.current_a.size), "flags": f.flags}
    hb = json.dumps(header, separators=(",", ":")).encode("ascii")
    hb += b" " * ((-(4 + len(hb))) % 4)
    return (struct.pack("<I", len(hb)) + hb
            + f.current_a.astype("<f4").tobytes() + f.voltage_v.astype("<f4").tobytes())


class Controller:
    def __init__(self, cfg: dict, cfg_path: Path) -> None:
        self.cfg = cfg
        self.cfg_path = cfg_path
        self.loop: asyncio.AbstractEventLoop | None = None
        self.clients: set[web.WebSocketResponse] = set()
        self.status: dict = {"state": "connecting", "message": "Starting", "armed": False}
        self.latest: bytes | None = None
        self.ring: "OrderedDict[int, Frame]" = OrderedDict()
        self.acq: Acquisition | None = None
        self.log_dir = APP_DIR / cfg["logging"]["directory"]
        self.cap_dir = APP_DIR / cfg["logging"]["captures_directory"]
        self.data_dir = APP_DIR / "data"
        self.panel_path = self.data_dir / "panel_settings.json"

    # ------------------------------------------------ callbacks from the acquisition thread
    def on_status(self, st: dict) -> None:
        if self.loop:
            asyncio.run_coroutine_threadsafe(self._status_async(st), self.loop)

    def on_frame(self, f: Frame) -> None:
        if self.loop:
            asyncio.run_coroutine_threadsafe(self._frame_async(f), self.loop)

    async def _status_async(self, st: dict) -> None:
        self.status = st
        await self._broadcast_text(json.dumps({"type": "status", "status": st}))

    async def _frame_async(self, f: Frame) -> None:
        data = encode_frame(f)
        self.latest = data
        self.ring[f.seq] = f
        while len(self.ring) > 30:
            self.ring.popitem(last=False)
        if self.cfg["logging"]["save_captures"] == "all":
            await asyncio.get_running_loop().run_in_executor(None, self.write_capture, f, "ALL")
        await self._broadcast_bytes(data)

    async def _broadcast_bytes(self, data: bytes) -> None:
        for ws in list(self.clients):
            try:
                await ws.send_bytes(data)
            except Exception:
                self.clients.discard(ws)

    async def _broadcast_text(self, text: str) -> None:
        for ws in list(self.clients):
            try:
                await ws.send_str(text)
            except Exception:
                self.clients.discard(ws)

    # ------------------------------------------------------------------------- logging
    def write_capture(self, f: Frame, tag: str) -> Path:
        """Write a capture as TIME,CH1,CH2 so plot_waveform.py / plot_waveform_elvp.py can open it.

        CH1 = amperes / 0.1 (those scripts multiply CH1 by 0.1), CH2 = volts.
        """
        self.cap_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.fromtimestamp(f.wall_time).strftime("%Y%m%d_%H%M%S")
        path = self.cap_dir / ("capture_%s_%s_seq%d.csv" % (stamp, tag, f.seq))
        t = f.t0 + np.arange(f.current_a.size) * f.dt
        table = np.column_stack((t, f.current_a / LEGACY_CH1_SCALE, f.voltage_v))
        np.savetxt(path, table, delimiter=",", header="TIME,CH1,CH2", comments="", fmt="%.9g")
        files = sorted(self.cap_dir.glob("capture_*.csv"))
        for old in files[: max(0, len(files) - self.cfg["logging"]["max_capture_files"])]:
            try:
                old.unlink()
            except OSError:
                pass
        return path

    def log_alarm(self, seq: int, events: list[dict]) -> int:
        self.log_dir.mkdir(parents=True, exist_ok=True)
        now = datetime.now()
        path = self.log_dir / ("alarms_%s.csv" % now.strftime("%Y-%m-%d"))
        new = not path.exists()
        with path.open("a", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            if new:
                w.writerow(["timestamp", "frame_seq", "limit_range", "type", "time_s", "power_w", "limit_w"])
            for e in events:
                w.writerow([now.isoformat(timespec="milliseconds"), seq, e["range"], e["type"],
                            "%.6f" % e["time_s"], "%.6f" % e["power_w"], "%.6f" % e["limit_w"]])
        if self.cfg["logging"]["save_captures"] == "alarms" and seq in self.ring:
            self.write_capture(self.ring[seq], "ALARM")
        return len(events)


# ------------------------------------------------------------------------------ web layer
def _same_origin(request: web.Request) -> bool:
    origin = request.headers.get("Origin")
    return origin is None or urlparse(origin).netloc == request.headers.get("Host", "")


@web.middleware
async def guard(request: web.Request, handler):
    """Refuse cross-site requests (a web page elsewhere on this PC must not be able to drive the controller)."""
    unsafe = request.method not in ("GET", "HEAD", "OPTIONS")
    if (unsafe or request.path == "/ws") and not _same_origin(request):
        return web.json_response({"error": "cross-origin request refused"}, status=403)
    if unsafe and request.can_read_body and request.content_type != "application/json":
        return web.json_response({"error": "Content-Type must be application/json"}, status=415)
    return await handler(request)


async def index(request: web.Request) -> web.StreamResponse:
    return web.FileResponse(APP_DIR / "web" / "index.html", headers={"Cache-Control": "no-store"})


async def api_info(request: web.Request) -> web.Response:
    ctl: Controller = request.app["ctl"]
    return web.json_response({"app": "us-power-controller", "version": VERSION,
                              "driver": ctl.cfg["scope"]["driver"]})


async def api_scope_get(request: web.Request) -> web.Response:
    ctl: Controller = request.app["ctl"]
    return web.json_response({"config": ctl.cfg["scope"], "status": ctl.status, "ranges": RANGES_V})


async def api_scope_put(request: web.Request) -> web.Response:
    ctl: Controller = request.app["ctl"]
    try:
        body = await request.json()
        new_scope = validate_scope(deep_merge(ctl.cfg["scope"], body.get("config", {})))
        new_scope["driver"] = ctl.cfg["scope"]["driver"]          # driver is chosen at start-up only
    except (ValueError, TypeError, AttributeError) as exc:
        return web.json_response({"error": str(exc)}, status=400)
    ctl.cfg["scope"] = new_scope
    save_config(ctl.cfg_path, ctl.cfg)
    ctl.acq.reconfigure()
    return web.json_response({"config": new_scope, "status": ctl.status})


async def api_acquire(request: web.Request) -> web.Response:
    ctl: Controller = request.app["ctl"]
    try:
        run = bool((await request.json())["run"])
    except Exception:
        return web.json_response({"error": "expected JSON {\"run\": true|false}"}, status=400)
    ctl.acq.set_armed(run)
    ctl.status = dict(ctl.status, armed=run)
    await ctl._broadcast_text(json.dumps({"type": "status", "status": ctl.status}))
    return web.json_response({"armed": run})


async def api_panel_get(request: web.Request) -> web.Response:
    ctl: Controller = request.app["ctl"]
    if not ctl.panel_path.exists():
        return web.Response(status=204)
    return web.Response(text=ctl.panel_path.read_text(encoding="utf-8"), content_type="application/json")


async def api_panel_put(request: web.Request) -> web.Response:
    ctl: Controller = request.app["ctl"]
    try:
        data = await request.json()
        if not isinstance(data, dict):
            raise ValueError("panel settings must be a JSON object")
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    atomic_write_text(ctl.panel_path, json.dumps(data, indent=1))
    return web.json_response({"saved": True})


async def api_panel_delete(request: web.Request) -> web.Response:
    ctl: Controller = request.app["ctl"]
    try:
        ctl.panel_path.unlink()
    except FileNotFoundError:
        pass
    return web.json_response({"deleted": True})


_ALARM_TYPES = {"HIGH", "LOW"}


async def api_alarm(request: web.Request) -> web.Response:
    ctl: Controller = request.app["ctl"]
    try:
        body = await request.json()
        seq = int(body["seq"])
        events = []
        for e in list(body["events"])[:50]:
            kind = str(e["type"]).upper()
            if kind not in _ALARM_TYPES:
                raise ValueError("bad alarm type")
            events.append({"range": int(e["range"]), "type": kind, "time_s": float(e["time_s"]),
                           "power_w": float(e["power_w"]), "limit_w": float(e["limit_w"])})
    except (KeyError, TypeError, ValueError):
        return web.json_response({"error": "malformed alarm record"}, status=400)
    count = await asyncio.get_running_loop().run_in_executor(None, ctl.log_alarm, seq, events)
    return web.json_response({"logged": count})


async def ws_handler(request: web.Request) -> web.WebSocketResponse:
    ctl: Controller = request.app["ctl"]
    ws = web.WebSocketResponse(heartbeat=15, max_msg_size=1 << 16)
    await ws.prepare(request)
    ctl.clients.add(ws)
    await ws.send_str(json.dumps({"type": "hello", "status": ctl.status}))
    if ctl.latest:
        await ws.send_bytes(ctl.latest)
    try:
        async for _ in ws:       # the client sends nothing we act on; control goes through the REST API
            pass
    finally:
        ctl.clients.discard(ws)
    return ws


def build_app(ctl: Controller, open_browser_url: str | None) -> web.Application:
    app = web.Application(middlewares=[guard])
    app["ctl"] = ctl
    app.add_routes([
        web.get("/", index),
        web.get("/ws", ws_handler),
        web.get("/api/info", api_info),
        web.get("/api/scope", api_scope_get),
        web.put("/api/scope", api_scope_put),
        web.post("/api/acquire", api_acquire),
        web.get("/api/panel", api_panel_get),
        web.put("/api/panel", api_panel_put),
        web.delete("/api/panel", api_panel_delete),
        web.post("/api/alarm", api_alarm),
    ])

    async def on_startup(app: web.Application) -> None:
        ctl.loop = asyncio.get_running_loop()
        ctl.acq = Acquisition(lambda: make_scope(ctl.cfg["scope"]["driver"]),
                              lambda: ctl.cfg["scope"], ctl.on_frame, ctl.on_status)
        ctl.acq.set_armed(ctl.cfg["server"]["autostart_monitoring"])
        ctl.acq.start()
        if open_browser_url:
            ctl.loop.call_later(1.0, lambda: webbrowser.open(open_browser_url))

    async def on_cleanup(app: web.Application) -> None:
        if ctl.acq:
            await asyncio.get_running_loop().run_in_executor(None, ctl.acq.shutdown)

    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)
    return app


# ----------------------------------------------------------------------------- self test
def selftest(cfg: dict) -> int:
    """Open the scope, take one capture (auto trigger forced on) and print a commissioning report."""
    scfg = validate_scope(deep_merge(cfg["scope"], {"trigger": {"auto_ms": 500}}))
    scope = make_scope(scfg["driver"])
    try:
        info = scope.open()
        print("Scope      :", info.get("model"), info.get("serial", ""))
        applied = scope.configure(scfg)
        print("Timebase   : %.3f us/sample (%.1f kS/s), %d samples = %.1f ms window, Nyquist %.1f kHz" % (
            applied["dt"] * 1e6, applied["sample_rate"] / 1e3, applied["samples"],
            applied["window_s"] * 1e3, applied["sample_rate"] / 2e3))
        scope.arm()
        deadline = time.monotonic() + 5
        while not scope.is_ready():
            if time.monotonic() > deadline:
                print("No capture within 5 s - check the trigger settings.")
                return 2
            time.sleep(0.01)
        raw = scope.read()
        for name, v, rng in (("CH1 (CT1)", raw.ch1_v, scfg["ch1"]["range_v"]),
                             ("CH2 (volt)", raw.ch2_v, scfg["ch2"]["range_v"])):
            pk = float(np.max(np.abs(v)))
            print("%-11s: peak %.4f V at scope input (range +/-%g V, %.0f %% of range), rms %.4f V" % (
                name, pk, rng, 100.0 * pk / rng, float(np.sqrt(np.mean(v.astype(np.float64) ** 2)))))
        f = Frame(0, time.time(), raw.t0, raw.dt, (raw.ch1_v / scfg["ch1"]["volts_per_amp"]),
                  raw.ch2_v * scfg["ch2"]["probe_ratio"], raw.flags)
        p = f.current_a.astype(np.float64) * f.voltage_v.astype(np.float64)
        print("Scaled     : I peak %.4f A, V peak %.3f V, instantaneous P peak %.3f W" % (
            float(np.max(np.abs(f.current_a))), float(np.max(np.abs(f.voltage_v))), float(p.max())))
        for ch in (1, 2):
            if raw.flags.get("clip_ch%d" % ch) or raw.flags.get("overflow_ch%d" % ch):
                print("WARNING    : CH%d is clipping - select a larger range." % ch)
        print("Self-test finished.")
        return 0
    except Exception as exc:
        print("Self-test failed:", exc)
        return 1
    finally:
        try:
            scope.close()
        except Exception:
            pass


def setup_logging(log_dir: Path) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    console = logging.StreamHandler()
    console.setFormatter(fmt)
    fh = logging.handlers.RotatingFileHandler(log_dir / "controller.log", maxBytes=1_000_000,
                                              backupCount=5, encoding="utf-8")
    fh.setFormatter(fmt)
    root.addHandler(console)
    root.addHandler(fh)
    logging.getLogger("aiohttp.access").setLevel(logging.WARNING)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="US Power Monitoring Controller (PicoScope 2204A)")
    ap.add_argument("--config", default=str(APP_DIR / "config.json"), help="path to config.json")
    ap.add_argument("--simulate", action="store_true", help="use the built-in simulated scope")
    ap.add_argument("--selftest", action="store_true", help="capture once and print a commissioning report")
    ap.add_argument("--diagnose", action="store_true", help="find out why the PicoScope cannot be opened")
    ap.add_argument("--host", help="override server.host")
    ap.add_argument("--port", type=int, help="override server.port")
    ap.add_argument("--no-browser", action="store_true", help="do not open the browser automatically")
    args = ap.parse_args(argv)

    cfg_path = Path(args.config)
    cfg = load_config(cfg_path)
    if args.simulate:
        cfg["scope"]["driver"] = "sim"
    if args.host:
        cfg["server"]["host"] = args.host
    if args.port:
        cfg["server"]["port"] = args.port

    if args.diagnose:
        import diagnose
        return diagnose.run()

    if args.selftest:
        return selftest(cfg)

    setup_logging(APP_DIR / cfg["logging"]["directory"])
    ctl = Controller(cfg, cfg_path)
    host, port = cfg["server"]["host"], cfg["server"]["port"]
    browse_host = "127.0.0.1" if host in ("0.0.0.0", "::") else host
    url = "http://%s:%d/" % (browse_host, port)
    app = build_app(ctl, None if (args.no_browser or not cfg["server"]["open_browser"]) else url)
    log.info("US Power Monitoring Controller %s - driver '%s' - %s", VERSION, cfg["scope"]["driver"], url)
    web.run_app(app, host=host, port=port, print=None, handle_signals=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
