"""Tektronix TBS1000C-series oscilloscope (e.g. TBS1052C) over USB or LAN, using SCPI through PyVISA.

Single-sequence acquisition: arm (ACQuire:STOPAfter SEQuence + ACQuire:STATE ON) -> wait for the trigger (the
scope stops by itself) -> read both channels from the same stopped acquisition (CURVe?) -> scale to volts.

Requirements: `pip install pyvisa` plus a VISA backend - TekVISA or NI-VISA (installed on the PC), or
`pip install pyvisa-py pyusb` with a libusb driver.  The scope's inputs are 1 MOhm: the CT1 still needs a
50 ohm feed-through terminator on CH1.  The scope's own probe attenuation is kept at 1x; the voltage-probe ratio
is applied by this program (config scope.ch2.probe_ratio).

The SCPI sequence follows the TBS1000C Programmer Manual (077-1691-01); it has not been run against a real
instrument by the author - see the README, section 'Tektronix TBS1000C'.
"""
from __future__ import annotations

import logging
import time

import numpy as np

from common import ScopeRaw

log = logging.getLogger("acquisition")
_TEK_VENDOR = "0x0699"
_VDIV = 8.0                 # vertical divisions: range (+/- V) = 4 x volts/div
_HDIV = 10.0                # horizontal divisions
_CLIP_RAW = 124             # |raw| >= this (of 127) counts as clipping
_ARM_SETTLE_S = 0.05


def _load_visa():
    try:
        import pyvisa
    except Exception as exc:
        raise RuntimeError(
            "PyVISA is not installed (%s). Run 'pip install pyvisa' and install a VISA backend: TekVISA or NI-VISA "
            "(or 'pip install pyvisa-py pyusb')." % exc) from exc
    return pyvisa


class TekTBS1000C:
    model = "Tektronix TBS1000C"

    def __init__(self) -> None:
        self.visa = _load_visa()
        self.rm = None
        self.inst = None
        self._cfg: dict | None = None
        self._n = 0
        self._armed_at = 0.0

    def prepare(self, cfg: dict) -> None:
        self._cfg = cfg

    # ------------------------------------------------------------------ helpers
    def _w(self, cmd: str) -> None:
        self.inst.write(cmd)

    def _q(self, cmd: str) -> str:
        return str(self.inst.query(cmd)).strip()

    def _qf(self, cmd: str) -> float:
        return float(self._q(cmd).split()[-1])

    def _find_resource(self, wanted: str) -> str:
        if wanted:
            return wanted
        found = list(self.rm.list_resources())
        tek = [r for r in found if _TEK_VENDOR.lower() in r.lower()] or [r for r in found if r.upper().startswith("USB")]
        if not tek:
            raise RuntimeError(
                "No Tektronix oscilloscope found through VISA (resources seen: %s). Check the USB cable (use the "
                "scope's USB DEVICE port), that TekVISA/NI-VISA is installed, and that no other program (OpenChoice, "
                "TekVisa tools) holds the scope. For LAN set scope.dso.resource to e.g. 'TCPIP0::192.168.1.20::INSTR'."
                % (found or "none"))
        return tek[0]

    # --------------------------------------------------------------------- open
    def open(self) -> dict:
        dso = (self._cfg or {}).get("dso", {}) if self._cfg else {}
        self.rm = self.visa.ResourceManager()
        res = self._find_resource(str(dso.get("resource", "")))
        self.inst = self.rm.open_resource(res)
        self.inst.timeout = 10000
        self.inst.read_termination = "\n"
        self.inst.write_termination = "\n"
        idn = self._q("*IDN?").split(",")
        self._w("HEADer OFF")
        self.model = ("%s %s" % (idn[0].strip().title(), idn[1].strip())) if len(idn) > 1 else "Tektronix scope"
        return {"model": self.model, "serial": idn[2].strip() if len(idn) > 2 else "", "resource": res}

    # ---------------------------------------------------------------- configure
    def configure(self, cfg: dict) -> dict:
        self._cfg = cfg
        self.stop()
        window_s = cfg["capture_window_ms"] / 1000.0
        pre = cfg["pre_trigger_pct"] / 100.0
        sign = -1.0 if cfg.get("dso", {}).get("position_sign", 1) < 0 else 1.0

        for idx, key in enumerate(("ch1", "ch2"), start=1):
            c = cfg[key]
            self._w("SELect:CH%d ON" % idx)
            self._w("CH%d:COUPling %s" % (idx, c["coupling"]))
            self._w("CH%d:SCAle %.6g" % (idx, c["range_v"] / (_VDIV / 2)))
            self._w("CH%d:POSition 0" % idx)
            try:                                   # keep the scope's probe at 1x; our scaling does the rest
                self._w("CH%d:PRObe:GAIN 1" % idx)
            except Exception:
                pass
        scale = window_s / _HDIV
        self._w("HORizontal:SCAle %.6g" % scale)
        self._w("HORizontal:POSition %.6g" % (sign * (0.5 - pre) * window_s))

        trig = cfg["trigger"]
        self._w("TRIGger:A:TYPe EDGe")
        if trig["source"] == "NONE":
            self._w("TRIGger:A:MODe AUTO")
        else:
            ch = 1 if trig["source"] == "CH1" else 2
            self._w("TRIGger:A:EDGe:SOUrce CH%d" % ch)
            self._w("TRIGger:A:EDGe:SLOpe %s" % ("RISe" if trig["direction"] == "RISING" else "FALL"))
            self._w("TRIGger:A:EDGe:COUPling DC")
            self._w("TRIGger:A:LEVel %.6g" % trig["level_v"])
            self._w("TRIGger:A:MODe %s" % ("AUTO" if trig["auto_ms"] > 0 else "NORMal"))
        self._w("ACQuire:MODe SAMple")
        self._w("DATa:ENCdg RIBinary")
        self._w("DATa:WIDth 1")
        self._w("DATa:STARt 1")
        self._n = int(self._qf("HORizontal:RECOrdlength?"))
        self._w("DATa:STOP %d" % self._n)
        real_scale = self._qf("HORizontal:SCAle?")
        probe_warn = [i for i in (1, 2) if abs(self._probe_gain(i) - 1.0) > 1e-6]
        if probe_warn:
            log.warning("Scope probe attenuation on CH%s is not 1x - set it to 1x on the scope, the ratio is applied by "
                        "this program", probe_warn)
        dt = real_scale * _HDIV / self._n
        return {
            "dt": dt, "samples": self._n, "pre_samples": int(round(self._n * pre)), "post_samples": self._n - int(round(self._n * pre)),
            "window_s": real_scale * _HDIV, "timebase": real_scale, "sample_rate": 1.0 / dt,
            "samples_requested": int(cfg["samples"]),
        }

    def _probe_gain(self, ch: int) -> float:
        try:
            return self._qf("CH%d:PRObe:GAIN?" % ch)
        except Exception:
            return 1.0

    # --------------------------------------------------------------- capture
    def arm(self) -> None:
        self._w("ACQuire:STOPAfter SEQuence")
        self._w("ACQuire:STATE ON")
        self._armed_at = time.monotonic()

    def is_ready(self) -> bool:
        if time.monotonic() - self._armed_at < _ARM_SETTLE_S:
            return False
        return int(self._qf("ACQuire:STATE?")) == 0          # 0 = sequence finished, scope stopped

    def _read_channel(self, idx: int):
        self._w("DATa:SOUrce CH%d" % idx)
        ymult = self._qf("WFMOutpre:YMUlt?")
        yoff = self._qf("WFMOutpre:YOFf?")
        yzero = self._qf("WFMOutpre:YZEro?")
        xincr = self._qf("WFMOutpre:XINcr?")
        xzero = self._qf("WFMOutpre:XZEro?")
        raw = self.inst.query_binary_values("CURVe?", datatype="b", container=np.array, expect_termination=False)
        volts = ((raw.astype(np.float64) - yoff) * ymult + yzero).astype(np.float32)
        clip = bool(raw.size and int(np.abs(raw.astype(np.int32)).max()) >= _CLIP_RAW)
        return volts, xincr, xzero, clip

    def read(self) -> ScopeRaw:
        v1, dt1, t01, clip1 = self._read_channel(1)
        v2, dt2, t02, clip2 = self._read_channel(2)
        m = min(v1.size, v2.size)
        if m == 0:
            raise RuntimeError("The oscilloscope returned no waveform data")
        return ScopeRaw(t0=t01, dt=dt1, ch1_v=v1[:m], ch2_v=v2[:m],
                        flags={"clip_ch1": clip1, "clip_ch2": clip2, "overflow_ch1": False, "overflow_ch2": False})

    def stop(self) -> None:
        if self.inst is not None:
            try:
                self._w("ACQuire:STATE OFF")
            except Exception:
                pass

    def close(self) -> None:
        try:
            self.stop()
            if self.inst is not None:
                self.inst.close()
        finally:
            self.inst = None
            if self.rm is not None:
                try:
                    self.rm.close()
                except Exception:
                    pass
                self.rm = None
