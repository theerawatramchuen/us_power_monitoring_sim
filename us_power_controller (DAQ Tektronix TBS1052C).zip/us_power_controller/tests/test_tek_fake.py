"""Exercises scope_tek.TekTBS1000C against a fake PyVISA (no instrument needed).  Run: python tests/test_tek_fake.py"""
import sys, types
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


class FakeInst:
    def __init__(self):
        self.sent, self.state_polls, self.source = [], 0, 1
        self.timeout = 0; self.read_termination = self.write_termination = ""
    def write(self, c): self.sent.append(c); self.source = int(c[-1]) if c.startswith("DATa:SOUrce") else self.source
    def query(self, c):
        self.sent.append(c)
        if c == "*IDN?": return "TEKTRONIX,TBS1052C,C012345,CF:91.1CT FV:v1.0\n"
        if c == "HORizontal:RECOrdlength?": return "20000\n"
        if c == "HORizontal:SCAle?": return "0.01\n"
        if c.startswith("CH") and c.endswith("PRObe:GAIN?"): return "1\n"
        if c == "ACQuire:STATE?":
            self.state_polls += 1; return ("1" if self.state_polls < 3 else "0") + "\n"
        return {"WFMOutpre:YMUlt?": "0.01", "WFMOutpre:YOFf?": "0", "WFMOutpre:YZEro?": "0",
                "WFMOutpre:XINcr?": "5e-06", "WFMOutpre:XZEro?": "-0.002"}[c] + "\n"
    def query_binary_values(self, c, datatype, container, expect_termination):
        n = 20000; t = np.arange(n)
        amp = 60 if self.source == 1 else 127          # CH2 saturates
        return container(np.clip(amp * np.sin(t / 9.0), -127, 127).astype(np.int8))
    def close(self): self.sent.append("CLOSE")


class FakeRM:
    inst = FakeInst()
    def list_resources(self): return ("USB0::0x0699::0x03C4::C012345::INSTR",)
    def open_resource(self, r): self.opened = r; return FakeRM.inst
    def close(self): pass


def install():
    FakeRM.inst = FakeInst()
    mod = types.ModuleType("pyvisa"); mod.ResourceManager = FakeRM
    sys.modules["pyvisa"] = mod; sys.modules.pop("scope_tek", None)
    return FakeRM.inst


def cfg(**o):
    from config import validate_scope
    return validate_scope(o)


def test_flow():
    inst = install()
    from scope_tek import TekTBS1000C
    from common import scale_capture
    s = TekTBS1000C(); c = cfg(driver="tbs1000c", ch1={"range_v": 1.0}, ch2={"range_v": 5.0})
    s.prepare(c)
    info = s.open()
    assert info["model"] == "Tektronix TBS1052C" and info["serial"] == "C012345", info
    a = s.configure(c)
    assert a["samples"] == 20000 and abs(a["dt"] - 5e-6) < 1e-12 and abs(a["window_s"] - 0.1) < 1e-9, a
    assert "CH1:SCAle 0.25" in inst.sent and "CH2:SCAle 1.25" in inst.sent
    assert "TRIGger:A:EDGe:SOUrce CH2" in inst.sent and "TRIGger:A:EDGe:SLOpe RISe" in inst.sent
    assert "TRIGger:A:LEVel 0.5" in inst.sent and "TRIGger:A:MODe NORMal" in inst.sent
    assert "HORizontal:POSition 0.048" in inst.sent, [x for x in inst.sent if "POS" in x]   # (0.5-0.02)*0.1
    s.arm(); assert not s.is_ready()
    import time; time.sleep(0.06)
    ready = False
    for _ in range(5):
        if s.is_ready(): ready = True; break
    assert ready
    raw = s.read()
    assert raw.ch1_v.size == 20000 and abs(raw.t0 + 0.002) < 1e-12 and abs(raw.dt - 5e-6) < 1e-12
    assert abs(float(raw.ch1_v.max()) - 0.6) < 0.02 and raw.flags["clip_ch2"] and not raw.flags["clip_ch1"], raw.flags
    f = scale_capture(raw, c, 1, 0.0)
    assert abs(float(f.current_a.max()) - 0.12) < 0.003 and abs(float(f.voltage_v.max()) - 12.7) < 0.2
    s.close(); assert inst.sent[-1] == "CLOSE"


def test_none_trigger_and_falling():
    inst = install()
    from scope_tek import TekTBS1000C
    s = TekTBS1000C(); s.open()
    s.configure(cfg(trigger={"source": "NONE"})); assert "TRIGger:A:MODe AUTO" in inst.sent
    s.configure(cfg(trigger={"source": "CH1", "direction": "FALLING", "auto_ms": 100}))
    assert "TRIGger:A:EDGe:SLOpe FALL" in inst.sent and "TRIGger:A:EDGe:SOUrce CH1" in inst.sent


def test_no_scope_message():
    install(); FakeRM.list_resources = lambda self: ()
    from scope_tek import TekTBS1000C
    try: TekTBS1000C().open()
    except RuntimeError as e: assert "No Tektronix" in str(e), e
    else: raise AssertionError
    FakeRM.list_resources = lambda self: ("USB0::0x0699::0x03C4::C012345::INSTR",)


def test_missing_pyvisa():
    sys.modules["pyvisa"] = None; sys.modules.pop("scope_tek", None)
    import scope_tek
    try: scope_tek.TekTBS1000C()
    except RuntimeError as e: assert "pip install pyvisa" in str(e)
    else: raise AssertionError
    sys.modules.pop("pyvisa", None); sys.modules.pop("scope_tek", None)


if __name__ == "__main__":
    ts = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in ts: t(); print("PASS", t.__name__)
    print("ALL %d PASSED" % len(ts))
