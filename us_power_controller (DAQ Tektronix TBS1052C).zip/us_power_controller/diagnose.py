"""`python app.py --diagnose` - find out why the PicoScope cannot be opened.

Checks, in order: Python bitness, the picosdk wrapper and ps2000a driver DLL, PicoScope programs that may be holding
the scope, what Windows sees on USB (Pico Technology vendor id 0CE9), what the driver itself enumerates, and finally
a real open attempt.  Everything is printed in plain ASCII so it works in any Windows console.
"""
from __future__ import annotations

import ctypes
import ctypes.util
import struct
import subprocess
import sys

PICO_USB_VENDOR = "0CE9"


def _run(cmd: list[str], timeout: int = 20) -> str:
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (out.stdout or "") + (out.stderr or "")
    except Exception as exc:                      # missing powershell/tasklist, timeout, ...
        return "(could not run %s: %s)" % (cmd[0], exc)


def _section(title: str) -> None:
    print("\n== " + title)


def run() -> int:
    findings: list[str] = []
    print("US Power Monitoring Controller - PicoScope diagnostics")

    _section("Python")
    bits = struct.calcsize("P") * 8
    print("Python %s, %d-bit, platform %s" % (sys.version.split()[0], bits, sys.platform))
    if bits != 64:
        findings.append("Python is %d-bit. Use 64-bit Python together with the 64-bit PicoSDK." % bits)

    _section("PicoSDK driver")
    try:
        from importlib.metadata import version
        print("picosdk package:", version("picosdk"))
    except Exception:
        print("picosdk package: not found by pip metadata")
    print("ps2000 library on PATH: ", ctypes.util.find_library("ps2000") or "NOT FOUND")
    print("ps2000a library on PATH:", ctypes.util.find_library("ps2000a") or "NOT FOUND")
    ps = None
    try:
        from picosdk.ps2000a import ps2000a as ps
        print("ps2000a driver loaded: OK")
    except Exception as exc:
        print("ps2000a driver load FAILED:", exc)
    ps_old = None
    try:
        from picosdk.ps2000 import ps2000 as ps_old
        print("ps2000 driver loaded: OK")
    except Exception as exc:
        print("ps2000 driver load FAILED:", exc)
    if ps is None and ps_old is None:
        findings.append("No PicoScope driver could be loaded. Install the 64-bit PicoSDK or PicoScope 7 from picotech.com.")

    if sys.platform == "win32":
        _section("PicoScope programs currently running (they can hold the scope)")
        tasks = _run(["tasklist", "/FO", "CSV", "/NH"])
        pico = sorted({line.split('","')[0].strip('"') for line in tasks.splitlines() if "pico" in line.lower()})
        if pico:
            print("\n".join("  " + p for p in pico))
            findings.append("A PicoScope program is running (%s). Close it completely - also from the system tray / Task Manager - "
                            "and start this program again. PicoScope 7 often starts by itself when the scope is plugged in." % ", ".join(pico))
        else:
            print("  none found")

        _section("Pico USB devices seen by Windows (vendor id %s)" % PICO_USB_VENDOR)
        ps_cmd = ("Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -like 'USB\\VID_%s*' } | "
                  "Format-List Status,Class,FriendlyName,InstanceId" % PICO_USB_VENDOR)
        listing = _run(["powershell", "-NoProfile", "-Command", ps_cmd]).strip()
        print(listing if listing else "  NONE - Windows does not see a Pico device")
        if not listing:
            findings.append("Windows does not see the scope on USB: try another cable and a direct USB port on the PC (no unpowered hub).")
        elif "Status" in listing and "OK" not in listing.split("Status", 1)[1].splitlines()[0]:
            findings.append("Windows lists the scope but its driver status is not OK. Reinstall the PicoSDK / PicoScope 7 and re-plug the scope.")
    else:
        print("\n(Windows-only checks skipped on %s)" % sys.platform)

    if ps is not None:
        _section("Units the driver can see")
        try:
            count, length = ctypes.c_int16(), ctypes.c_int16(256)
            serials = ctypes.create_string_buffer(256)
            status = ps.ps2000aEnumerateUnits(ctypes.byref(count), serials, ctypes.byref(length))
            print("status %s, units available to open: %d %s" % (status, count.value, serials.value.decode("ascii", "ignore")))
            if status == 0 and count.value == 0:
                findings.append("The driver sees no unit that is free to open: either the scope is not detected, or another program has it open.")
        except Exception as exc:
            print("enumeration not available:", exc)

        _section("Open attempt with the ps2000a driver")
        try:
            from scope_pico import PicoScope2000A
            scope = PicoScope2000A()
            info = scope.open()
            print("OPENED OK:", info)
            scope.close()
        except Exception as exc:
            print("FAILED:", exc)

    _section("Open attempt with the original ps2000 driver (PicoScope 2204A / 2205A)")
    if ps_old is None:
        print("skipped (driver not loaded)")
    else:
        try:
            from scope_pico2000 import PicoScope2000
            old = PicoScope2000()
            info = old.open()
            print("OPENED OK:", info)
            print("  -> use driver \"ps2000\" (or \"auto\") in config.json")
            old.close()
            findings = [f for f in findings if "no unit that is free" not in f]
        except Exception as exc:
            print("FAILED:", exc)

    _section("Tektronix oscilloscope (driver tbs1000c, PyVISA)")
    try:
        import pyvisa
        rm = pyvisa.ResourceManager()
        found = list(rm.list_resources())
        print("PyVISA %s, backend: %s" % (pyvisa.__version__, rm))
        print("VISA resources:", found or "none")
        for r in found:
            if "0x0699" in r.lower() or r.upper().startswith("TCPIP"):
                try:
                    inst = rm.open_resource(r); inst.timeout = 3000
                    print("  %s -> %s" % (r, str(inst.query("*IDN?")).strip())); inst.close()
                except Exception as exc:
                    print("  %s -> could not query: %s" % (r, exc))
    except Exception as exc:
        print("PyVISA not usable (only needed for a Tektronix scope):", exc)

    _section("Result")
    if findings:
        for f in findings:
            print(" *", f)
    else:
        print("No problem found. If the scope opened, run:  python app.py --selftest")
    return 1 if findings else 0
